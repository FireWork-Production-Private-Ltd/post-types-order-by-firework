=== Post Types Order by FireWork  ===
Contributors: nsp-code, fireworkproductionprivateltd, up1512001
Donate link: http://www.nsp-code.com/donate.php
Tags: post order, posts order, post sort, posts sort, post types order
Requires at least: 2.8
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2

This is the same plugin created by nsp code, now with all PHPCS warnings and issues removed for seamless use on VIP instances.