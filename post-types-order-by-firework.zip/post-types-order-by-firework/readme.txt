=== Post Types Order by FireWork  ===
Contributors: nsp-code, fireworkproductionprivateltd, up1512001
Donate link: http://www.nsp-code.com/donate.php
Tags: post order, posts order, post sort, posts sort, post types order
Requires at least: 2.8
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2

Sort Posts and custom Post Type Objects (custom post types) using a Drag and Drop Sortable JavaScript AJAX interface or default WordPress dashboard. 

This is same plugin created by `nsp code` I have removed all phpcs warning and issues to use this on `VIP` instance without any issue.